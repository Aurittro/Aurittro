const mongoose = require('mongoose');

// Connects to MongoDB using MONGODB_URI. The server only starts listening after this succeeds.
async function connectDB() {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/scholarbridge';
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log(`MongoDB connected: ${mongoose.connection.host}:${mongoose.connection.port}/${mongoose.connection.name}`);
  } catch (err) {
    console.error(`MongoDB connection failed (${uri}): ${err.message}`);
    console.error('Start MongoDB or fix MONGODB_URI in your .env file, then run the server again.');
    process.exit(1);
  }
}

module.exports = connectDB;

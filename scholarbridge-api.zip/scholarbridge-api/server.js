require('dotenv').config({ quiet: true });
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const errorHandler = require('./middleware/errorHandler');

if (!process.env.JWT_SECRET) {
  console.error('JWT_SECRET is missing. Copy .env.example to .env and run the server again.');
  process.exit(1);
}

const PORT = process.env.PORT || 1509; // last four digits of student ID 22301509

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => res.json({ service: 'ScholarBridge API', status: 'running', port: Number(PORT) }));
app.use('/api/proposals', require('./routes/proposals'));
app.use('/api/portfolio', require('./routes/portfolio'));

app.use((req, res) => res.status(404).json({ message: `Route ${req.method} ${req.originalUrl} not found` }));
app.use(errorHandler);

connectDB().then(() => {
  app.listen(PORT, (err) => {
    if (err) {
      console.error(`Could not start the server on port ${PORT}: ${err.message}`);
      process.exit(1);
    }
    console.log(`Server running on http://127.0.0.1:${PORT}`);
  });
});

// Creates demo users, a few sample portfolio entries, and a ready-to-import Postman environment.
// Run with: npm run seed   (safe to run more than once)
require('dotenv').config({ quiet: true });
const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const { PortfolioEntry } = require('../models/PortfolioEntry');

// Fixed ids so the generated Postman environment stays valid every time you re-seed.
const DEMO_USERS = [
  { key: 'student', _id: '650000000000000000000001', name: 'Demo Student', email: 'student@scholarbridge.test', role: 'student' },
  { key: 'student2', _id: '650000000000000000000002', name: 'Second Student', email: 'student2@scholarbridge.test', role: 'student' },
  { key: 'professor', _id: '650000000000000000000003', name: 'Dr. Demo Professor', email: 'professor@scholarbridge.test', role: 'professor' },
  { key: 'admin', _id: '650000000000000000000004', name: 'Demo Admin', email: 'admin@scholarbridge.test', role: 'admin' },
];

const SAMPLE_ENTRIES = {
  student: [
    { type: 'interest', title: 'Machine learning for healthcare' },
    { type: 'skill', title: 'Python', description: 'Data analysis and scripting' },
  ],
  professor: [
    { type: 'interest', title: 'Natural language processing' },
    { type: 'publication', title: 'Sample paper: transformer models for low-resource languages', organization: 'Sample Journal', link: 'https://example.com/paper' },
  ],
};

async function seed() {
  await connectDB();
  const port = process.env.PORT || 1509;
  const values = [{ key: 'baseUrl', value: `http://127.0.0.1:${port}`, type: 'default', enabled: true }];

  for (const demo of DEMO_USERS) {
    let user = await User.findOne({ email: demo.email });
    if (!user) user = await User.create({ _id: demo._id, name: demo.name, email: demo.email, role: demo.role });

    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '90d' });
    values.push({ key: `${demo.key}Token`, value: token, type: 'secret', enabled: true });
    values.push({ key: `${demo.key}Id`, value: user.id, type: 'default', enabled: true });

    const samples = SAMPLE_ENTRIES[demo.key] || [];
    if (samples.length > 0 && (await PortfolioEntry.countDocuments({ user: user._id })) === 0) {
      await PortfolioEntry.insertMany(samples.map((entry) => ({ ...entry, user: user._id })));
    }
    console.log(`${demo.role.padEnd(10)} ${user.email.padEnd(32)} id=${user.id}`);
  }

  const environment = {
    id: '3b6f1f0e-5a3c-4c3e-9d57-2f1c0a1509aa',
    name: `ScholarBridge Local (port ${port})`,
    values,
    _postman_variable_scope: 'environment',
  };
  const outFile = path.join(__dirname, '..', 'postman', 'ScholarBridge_Local.postman_environment.json');
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, JSON.stringify(environment, null, 2));
  console.log(`\nPostman environment written to ${path.relative(process.cwd(), outFile)}`);

  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error('Seeding failed:', err.message);
  process.exit(1);
});

// End-to-end check of all 11 APIs plus the main error cases.
// Start MongoDB, run `npm run seed`, start the server (`npm start`), then run: npm run smoke
require('dotenv').config({ quiet: true });
const jwt = require('jsonwebtoken');

const BASE = process.env.BASE_URL || `http://127.0.0.1:${process.env.PORT || 1509}`;
const ID = {
  student: '650000000000000000000001',
  student2: '650000000000000000000002',
  professor: '650000000000000000000003',
  admin: '650000000000000000000004',
};
const ROLE = { student: 'student', student2: 'student', professor: 'professor', admin: 'admin' };
const token = Object.fromEntries(
  Object.keys(ID).map((key) => [key, jwt.sign({ id: ID[key], role: ROLE[key] }, process.env.JWT_SECRET, { expiresIn: '1h' })])
);

let passed = 0;
let failed = 0;

async function call(method, path, who, body) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (who) headers.Authorization = `Bearer ${token[who] || who}`;
  const res = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  const json = await res.json().catch(() => null);
  return { status: res.status, json };
}

function check(label, condition, detail) {
  if (condition) {
    passed += 1;
    console.log(`  ok    ${label}`);
  } else {
    failed += 1;
    console.log(`  FAIL  ${label}${detail ? ` -> ${JSON.stringify(detail)}` : ''}`);
  }
}

const fullProposal = {
  title: 'Early detection of crop disease using lightweight vision models',
  researchProblem: 'Smallholder farmers cannot identify crop diseases early enough.',
  objectives: 'Build a mobile-friendly classifier and measure accuracy on field photos.',
  methodology: 'Collect a labelled leaf-image dataset, fine-tune a small CNN and evaluate it.',
  expectedOutcome: 'A model with over 90 percent accuracy that runs on a basic phone.',
};

async function run() {
  console.log(`Testing ${BASE}\n`);

  console.log('Server and authentication');
  let r = await call('GET', '/');
  check('GET / reports the server is running', r.status === 200 && r.json.status === 'running', r);
  r = await call('GET', '/api/proposals');
  check('no token -> 401', r.status === 401, r);
  r = await call('GET', '/api/proposals', 'not-a-real-token');
  check('bad token -> 401', r.status === 401, r);
  r = await call('GET', '/api/nothing-here', 'student');
  check('unknown route -> 404', r.status === 404, r);

  console.log('\nFeature 01 - Research Proposal Submission');
  r = await call('POST', '/api/proposals', 'student', { title: fullProposal.title });
  check('1.1 create draft -> 201 with status Draft', r.status === 201 && r.json.proposal.status === 'Draft', r);
  const draftId = r.json?.proposal?._id;
  check('1.1 history starts with one Draft entry', r.json?.proposal?.statusHistory?.length === 1, r.json);
  r = await call('POST', '/api/proposals', 'professor', { title: 'x' });
  check('1.1 professor cannot create -> 403', r.status === 403, r);
  r = await call('POST', '/api/proposals', 'student', { objectives: 'no title' });
  check('1.1 missing title -> 400', r.status === 400 && r.json.errors?.title, r);
  r = await call('POST', '/api/proposals', 'student', { title: 'x', status: 'Accepted' });
  check('1.1 client cannot set status', r.status === 201 && r.json.proposal.status === 'Draft', r);

  r = await call('PUT', `/api/proposals/${draftId}`, 'student', fullProposal);
  check('1.2 edit draft -> 200 and fields saved', r.status === 200 && r.json.proposal.methodology === fullProposal.methodology, r);
  r = await call('PUT', `/api/proposals/${draftId}`, 'student', {});
  check('1.2 empty body -> 400', r.status === 400, r);
  r = await call('PUT', `/api/proposals/${draftId}`, 'student2', { title: 'hijack' });
  check("1.2 another student's proposal -> 404", r.status === 404, r);
  r = await call('PUT', '/api/proposals/not-an-id', 'student', { title: 'x' });
  check('1.2 invalid id -> 400', r.status === 400, r);

  r = await call('GET', '/api/proposals?status=Draft', 'student');
  check('1.6 student lists own drafts', r.status === 200 && r.json.proposals.some((p) => p._id === draftId), r);
  r = await call('GET', '/api/proposals?status=Nope', 'student');
  check('1.6 unknown status filter -> 400', r.status === 400, r);
  r = await call('GET', '/api/proposals', 'student2');
  check('1.6 other student does not see it', r.status === 200 && !r.json.proposals.some((p) => p._id === draftId), r);
  r = await call('GET', '/api/proposals', 'professor');
  check('1.6 professor does not see drafts', r.status === 200 && !r.json.proposals.some((p) => p._id === draftId), r);

  r = await call('GET', `/api/proposals/${draftId}`, 'student');
  check('1.5 owner views draft', r.status === 200 && r.json.proposal.student.name === 'Demo Student', r);
  r = await call('GET', `/api/proposals/${draftId}`, 'student2');
  check('1.5 other student -> 403', r.status === 403, r);
  r = await call('GET', `/api/proposals/${draftId}`, 'professor');
  check('1.5 professor cannot open a draft -> 403', r.status === 403, r);
  r = await call('GET', '/api/proposals/650000000000000000009999', 'student');
  check('1.5 unknown id -> 404', r.status === 404, r);

  r = await call('POST', '/api/proposals', 'student', { title: 'Half-written idea' });
  const halfId = r.json?.proposal?._id;
  r = await call('POST', `/api/proposals/${halfId}/submit`, 'student');
  check('1.3 incomplete proposal cannot be submitted -> 400', r.status === 400 && r.json.missingFields?.length === 4, r);

  r = await call('POST', `/api/proposals/${draftId}/submit`, 'student');
  check('1.3 submit complete draft -> Submitted', r.status === 200 && r.json.proposal.status === 'Submitted' && r.json.proposal.submittedAt, r);
  r = await call('POST', `/api/proposals/${draftId}/submit`, 'student');
  check('1.3 submit twice -> 409', r.status === 409, r);
  r = await call('PUT', `/api/proposals/${draftId}`, 'student', { title: 'edit after submit' });
  check('1.2 edit after submit -> 409', r.status === 409, r);

  r = await call('GET', '/api/proposals', 'professor');
  check('1.6 professor sees the submitted proposal', r.status === 200 && r.json.proposals.some((p) => p._id === draftId), r);
  r = await call('PATCH', `/api/proposals/${draftId}/review`, 'student', { status: 'Accepted' });
  check('1.4 student cannot review -> 403', r.status === 403, r);
  r = await call('PATCH', `/api/proposals/${draftId}/review`, 'professor', { status: 'Draft' });
  check('1.4 invalid decision -> 400', r.status === 400, r);
  r = await call('PATCH', `/api/proposals/${draftId}/review`, 'professor', { status: 'Revision Required' });
  check('1.4 revision without feedback -> 400', r.status === 400, r);
  r = await call('PATCH', `/api/proposals/${halfId}/review`, 'professor', { status: 'Accepted' });
  check('1.4 reviewing a draft -> 404', r.status === 404, r);
  r = await call('PATCH', `/api/proposals/${draftId}/review`, 'professor', {
    status: 'Revision Required',
    feedback: 'Narrow the scope to one crop and add an evaluation plan.',
  });
  check('1.4 request revision -> Revision Required', r.status === 200 && r.json.proposal.status === 'Revision Required', r);

  r = await call('GET', `/api/proposals/${draftId}`, 'student');
  check('1.5 student sees feedback and 3-step history', r.status === 200 && r.json.proposal.feedback.includes('Narrow') && r.json.proposal.statusHistory.length === 3, r.json);
  r = await call('GET', `/api/proposals/${draftId}`, 'professor');
  check('1.5 reviewer can open a submitted proposal', r.status === 200 && r.json.proposal.reviewedBy.name === 'Dr. Demo Professor', r);
  r = await call('GET', '/api/proposals?status=Revision%20Required', 'student');
  check('1.6 filter by status Revision Required', r.status === 200 && r.json.proposals.every((p) => p.status === 'Revision Required') && r.json.count >= 1, r);

  r = await call('PUT', `/api/proposals/${draftId}`, 'student', { methodology: 'Focus on tomato leaves; hold out 20 percent of photos for testing.' });
  check('1.2 edit allowed again after revision request', r.status === 200, r);
  r = await call('POST', `/api/proposals/${draftId}/submit`, 'student');
  check('1.3 resubmit after revision', r.status === 200 && r.json.proposal.status === 'Submitted', r);
  r = await call('PATCH', `/api/proposals/${draftId}/review`, 'admin', { status: 'Accepted' });
  check('1.4 admin accepts without feedback', r.status === 200 && r.json.proposal.status === 'Accepted', r);
  r = await call('PATCH', `/api/proposals/${draftId}/review`, 'professor', { status: 'Rejected', feedback: 'late' });
  check('1.4 reviewing an Accepted proposal -> 409', r.status === 409, r);

  console.log('\nFeature 02 - Individual Research Portfolio');
  r = await call('GET', '/api/portfolio/me', 'student');
  check('2.3 view my portfolio (seeded sections)', r.status === 200 && r.json.portfolio.interest.length >= 1 && r.json.user.email, r);
  r = await call('POST', '/api/portfolio/entries', 'student', {
    type: 'publication',
    title: 'A survey of lightweight vision models',
    organization: 'Sample Conference 2026',
    link: 'https://example.com/survey',
    startDate: '2026-03-01',
  });
  check('2.1 add publication -> 201', r.status === 201 && r.json.entry.type === 'publication', r);
  const entryId = r.json?.entry?._id;
  r = await call('POST', '/api/portfolio/entries', 'student', { type: 'hobby', title: 'Chess' });
  check('2.1 unknown type -> 400', r.status === 400 && r.json.errors?.type, r);
  r = await call('POST', '/api/portfolio/entries', 'student', { type: 'skill' });
  check('2.1 missing title -> 400', r.status === 400 && r.json.errors?.title, r);
  r = await call('POST', '/api/portfolio/entries', 'student', { type: 'project', title: 'Demo', link: 'ftp://nope' });
  check('2.1 bad link -> 400', r.status === 400 && r.json.errors?.link, r);
  r = await call('POST', '/api/portfolio/entries', 'student', { type: 'experience', title: 'Intern', startDate: '2026-05-01', endDate: '2026-01-01' });
  check('2.1 endDate before startDate -> 400', r.status === 400 && r.json.errors?.endDate, r);

  r = await call('PUT', `/api/portfolio/entries/${entryId}`, 'student', { title: 'A survey of lightweight vision models (extended)', endDate: '2026-04-01' });
  check('2.2 edit entry -> 200', r.status === 200 && r.json.entry.title.includes('extended'), r);
  r = await call('PUT', `/api/portfolio/entries/${entryId}`, 'student2', { title: 'hijack' });
  check("2.2 another user's entry -> 404", r.status === 404, r);
  r = await call('PUT', `/api/portfolio/entries/${entryId}`, 'student', {});
  check('2.2 empty body -> 400', r.status === 400, r);

  r = await call('GET', `/api/portfolio/${ID.student}`, 'professor');
  check("2.4 professor views a student's portfolio", r.status === 200 && r.json.portfolio.publication.some((e) => e._id === entryId) && r.json.user.email === undefined, r);
  r = await call('GET', '/api/portfolio/650000000000000000009999', 'professor');
  check('2.4 unknown user -> 404', r.status === 404, r);
  r = await call('GET', '/api/portfolio/not-an-id', 'professor');
  check('2.4 invalid id -> 400', r.status === 400, r);

  r = await call('DELETE', `/api/portfolio/entries/${entryId}`, 'student2');
  check("2.5 another user cannot delete -> 404", r.status === 404, r);
  r = await call('DELETE', `/api/portfolio/entries/${entryId}`, 'student');
  check('2.5 delete entry -> 200', r.status === 200 && r.json.deletedId === entryId, r);
  r = await call('DELETE', `/api/portfolio/entries/${entryId}`, 'student');
  check('2.5 delete again -> 404', r.status === 404, r);
  r = await call('GET', '/api/portfolio/me', 'student');
  check('2.3 deleted entry is gone', r.status === 200 && !r.json.portfolio.publication.some((e) => e._id === entryId), r);

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed === 0 ? 0 : 1);
}

run().catch((err) => {
  console.error('Smoke test crashed:', err.message);
  process.exit(1);
});

const jwt = require('jsonwebtoken');

// Reads the "Authorization: Bearer <token>" header, verifies the JWT and puts { id, role } on req.user.
// Tokens are issued by the authentication module (login). `npm run seed` creates test tokens.
function auth(req, res, next) {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Missing or malformed Authorization header. Use: Bearer <token>' });
  }
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (!payload.id || !payload.role) throw new Error('Token payload must contain id and role');
    req.user = { id: payload.id, role: payload.role };
    next();
  } catch (err) {
    res.status(401).json({ message: 'Invalid or expired token' });
  }
}

// Lets the request through only when the logged-in user has one of the given roles.
const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user.role)
    ? next()
    : res.status(403).json({ message: `This action requires one of these roles: ${roles.join(', ')}` });

module.exports = { auth, requireRole };

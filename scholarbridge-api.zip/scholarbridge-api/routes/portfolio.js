const express = require('express');
const User = require('../models/User');
const { PortfolioEntry, ENTRY_TYPES } = require('../models/PortfolioEntry');
const { auth } = require('../middleware/auth');
const pick = require('../utils/pick');

const router = express.Router();
router.use(auth); // every portfolio API needs "Authorization: Bearer <token>"

const FIELDS = ['type', 'title', 'description', 'organization', 'link', 'startDate', 'endDate'];

// Groups entries into { interest: [...], skill: [...], publication: [...], project: [...], experience: [...] }
const groupByType = (entries) =>
  Object.fromEntries(ENTRY_TYPES.map((type) => [type, entries.filter((entry) => entry.type === type)]));

// Builds the portfolio response for one user (null when the user does not exist).
async function getPortfolio(userId, userFields) {
  const user = await User.findById(userId).select(userFields);
  if (!user) return null;
  const entries = await PortfolioEntry.find({ user: user._id }).sort({ createdAt: 1 });
  return { user, totalEntries: entries.length, portfolio: groupByType(entries) };
}

// API 2.1 - Add a research interest, skill, publication, project or experience
router.post('/entries', async (req, res) => {
  const entry = await PortfolioEntry.create({ ...pick(req.body, FIELDS), user: req.user.id });
  res.status(201).json({ message: 'Portfolio entry added', entry });
});

// API 2.2 - Edit one of my portfolio entries
router.put('/entries/:entryId', async (req, res) => {
  const entry = await PortfolioEntry.findOne({ _id: req.params.entryId, user: req.user.id });
  if (!entry) return res.status(404).json({ message: 'Portfolio entry not found' });
  const changes = pick(req.body, FIELDS);
  if (Object.keys(changes).length === 0) {
    return res.status(400).json({ message: `Send at least one of: ${FIELDS.join(', ')}` });
  }
  entry.set(changes);
  await entry.save();
  res.json({ message: 'Portfolio entry updated', entry });
});

// API 2.3 - View my own portfolio (must stay above "/:userId" so "me" is not read as a user id)
router.get('/me', async (req, res) => {
  const result = await getPortfolio(req.user.id, 'name email role');
  if (!result) return res.status(404).json({ message: 'User not found' });
  res.json(result);
});

// API 2.4 - View another user's portfolio (for example a professor reviewing an applicant)
router.get('/:userId', async (req, res) => {
  const result = await getPortfolio(req.params.userId, 'name role');
  if (!result) return res.status(404).json({ message: 'User not found' });
  res.json(result);
});

// API 2.5 - Delete one of my portfolio entries
router.delete('/entries/:entryId', async (req, res) => {
  const entry = await PortfolioEntry.findOneAndDelete({ _id: req.params.entryId, user: req.user.id });
  if (!entry) return res.status(404).json({ message: 'Portfolio entry not found' });
  res.json({ message: 'Portfolio entry deleted', deletedId: entry._id });
});

module.exports = router;

const express = require('express');
const { Proposal, STATUSES } = require('../models/Proposal');
const { auth, requireRole } = require('../middleware/auth');
const pick = require('../utils/pick');

const router = express.Router();
router.use(auth); // every proposal API needs "Authorization: Bearer <token>"

const FIELDS = ['title', 'researchProblem', 'objectives', 'methodology', 'expectedOutcome'];
const EDITABLE_STATUSES = ['Draft', 'Revision Required'];
const REVIEW_DECISIONS = ['Revision Required', 'Accepted', 'Rejected'];

// API 1.1 - Create a proposal (saved as a Draft)
router.post('/', requireRole('student'), async (req, res) => {
  const proposal = new Proposal({ ...pick(req.body, FIELDS), student: req.user.id });
  proposal.moveTo('Draft', req.user.id, 'Proposal created');
  await proposal.save();
  res.status(201).json({ message: 'Proposal saved as draft', proposal });
});

// API 1.2 - Edit a proposal (only while it is a Draft or needs revision)
router.put('/:id', requireRole('student'), async (req, res) => {
  const proposal = await Proposal.findOne({ _id: req.params.id, student: req.user.id });
  if (!proposal) return res.status(404).json({ message: 'Proposal not found' });
  if (!EDITABLE_STATUSES.includes(proposal.status)) {
    return res.status(409).json({ message: `A proposal with status "${proposal.status}" cannot be edited` });
  }
  const changes = pick(req.body, FIELDS);
  if (Object.keys(changes).length === 0) {
    return res.status(400).json({ message: `Send at least one of: ${FIELDS.join(', ')}` });
  }
  proposal.set(changes);
  await proposal.save();
  res.json({ message: 'Proposal updated', proposal });
});

// API 1.3 - Submit a proposal for review
router.post('/:id/submit', requireRole('student'), async (req, res) => {
  const proposal = await Proposal.findOne({ _id: req.params.id, student: req.user.id });
  if (!proposal) return res.status(404).json({ message: 'Proposal not found' });
  if (!EDITABLE_STATUSES.includes(proposal.status)) {
    return res.status(409).json({ message: `A proposal with status "${proposal.status}" cannot be submitted` });
  }
  const missingFields = FIELDS.filter((field) => !proposal[field]);
  if (missingFields.length > 0) {
    return res.status(400).json({ message: 'Fill in every field before submitting', missingFields });
  }
  proposal.submittedAt = new Date();
  proposal.moveTo('Submitted', req.user.id, 'Submitted for review');
  await proposal.save();
  res.json({ message: 'Proposal submitted for review', proposal });
});

// API 1.4 - Review a submitted proposal (professor or admin)
router.patch('/:id/review', requireRole('professor', 'admin'), async (req, res) => {
  const body = req.body || {};
  const feedback = typeof body.feedback === 'string' ? body.feedback.trim() : '';
  if (!REVIEW_DECISIONS.includes(body.status)) {
    return res.status(400).json({ message: `status must be one of: ${REVIEW_DECISIONS.join(', ')}` });
  }
  if (body.status !== 'Accepted' && !feedback) {
    return res.status(400).json({ message: `feedback is required when the status is "${body.status}"` });
  }
  const proposal = await Proposal.findById(req.params.id);
  if (!proposal || proposal.status === 'Draft') return res.status(404).json({ message: 'Proposal not found' });
  if (proposal.status !== 'Submitted') {
    return res.status(409).json({ message: `Only Submitted proposals can be reviewed (current status: "${proposal.status}")` });
  }
  proposal.feedback = feedback;
  proposal.reviewedBy = req.user.id;
  proposal.reviewedAt = new Date();
  proposal.moveTo(body.status, req.user.id, feedback);
  await proposal.save();
  res.json({ message: `Proposal marked as ${body.status}`, proposal });
});

// API 1.5 - View one proposal with its status, feedback and status history
router.get('/:id', async (req, res) => {
  const proposal = await Proposal.findById(req.params.id);
  if (!proposal) return res.status(404).json({ message: 'Proposal not found' });
  const isOwner = proposal.student.equals(req.user.id);
  const isReviewer = req.user.role !== 'student' && proposal.status !== 'Draft';
  if (!isOwner && !isReviewer) {
    return res.status(403).json({ message: 'You are not allowed to view this proposal' });
  }
  await proposal.populate([
    { path: 'student', select: 'name email' },
    { path: 'reviewedBy', select: 'name' },
  ]);
  res.json({ proposal });
});

// API 1.6 - List proposals: students see their own, professors and admins see submitted ones. Optional ?status=
router.get('/', async (req, res) => {
  const { status } = req.query;
  if (status && !STATUSES.includes(status)) {
    return res.status(400).json({ message: `status must be one of: ${STATUSES.join(', ')}` });
  }
  const filter = req.user.role === 'student' ? { student: req.user.id } : { status: { $ne: 'Draft' } };
  if (status) filter.$and = [{ status }]; // $and keeps reviewers from listing drafts even with ?status=Draft
  const proposals = await Proposal.find(filter)
    .select('title status student feedback submittedAt reviewedAt createdAt updatedAt')
    .sort({ updatedAt: -1 })
    .populate('student', 'name');
  res.json({ count: proposals.length, proposals });
});

module.exports = router;

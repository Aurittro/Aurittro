// Copies only the allowed keys that were actually sent, so clients cannot set fields such as status or student.
module.exports = (source = {}, keys) =>
  Object.fromEntries(keys.filter((key) => source[key] !== undefined).map((key) => [key, source[key]]));

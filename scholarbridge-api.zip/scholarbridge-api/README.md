# ScholarBridge API

REST APIs for **Feature 01 - Research Proposal Submission** and **Feature 02 - Individual Research Portfolio**.

CSE471 lab assignment (API Postman Collection) - Aurittro Hossain, ID 22301509, Section 03, Group 12.
Stack: Node.js, Express 5, MongoDB with Mongoose 8. The server runs on port **1509** (last four digits of the student ID).

## What you need

- Node.js 18 or newer
- MongoDB running on your computer (MongoDB Community Server, default port 27017), or a MongoDB Atlas connection string
- Postman

## Run it

1. `npm install`
2. The `.env` file already has working defaults (port 1509, local MongoDB). To use MongoDB Atlas, put your connection string in `MONGODB_URI`. `.env.example` shows every setting.
3. `npm run seed` creates four demo users (student, second student, professor, admin) and a few portfolio entries. It also writes `postman/ScholarBridge_Local.postman_environment.json` with a login token for each user. Run it again whenever you want fresh tokens (they last 90 days).
4. `npm start` should print `MongoDB connected` and `Server running on http://127.0.0.1:1509`.
5. Optional: `npm run smoke` runs 54 automated checks against the running server (all 11 APIs and their error cases).

## Test in Postman

1. Import `postman/ScholarBridge_API.postman_collection.json` and `postman/ScholarBridge_Local.postman_environment.json`.
2. Pick the environment **ScholarBridge Local (port 1509)** at the top right.
3. Send the requests from top to bottom. Requests 1.1 and 2.1 save the new ids automatically, so the later requests work without copying anything.
4. Take a screenshot of each request and its response for the report. The folder "Error cases (extra)" shows the 401, 403, 400 and 404 responses.

Without Postman: `npx newman run postman/ScholarBridge_API.postman_collection.json -e postman/ScholarBridge_Local.postman_environment.json`

## APIs

Every request needs the header `Authorization: Bearer <token>`. Requests with a JSON body also need `Content-Type: application/json`.

| ID | Method | URL | Who can call it | What it does |
| --- | --- | --- | --- | --- |
| 1.1 | POST | `/api/proposals` | student | Create a proposal (saved as Draft) |
| 1.2 | PUT | `/api/proposals/:id` | owner, while Draft or Revision Required | Edit a proposal |
| 1.3 | POST | `/api/proposals/:id/submit` | owner | Submit for review (all five fields must be filled) |
| 1.4 | PATCH | `/api/proposals/:id/review` | professor, admin | Mark as Revision Required, Accepted or Rejected, with feedback |
| 1.5 | GET | `/api/proposals/:id` | owner, or reviewer once submitted | View status, feedback and status history |
| 1.6 | GET | `/api/proposals?status=` | any user | List proposals (students see their own, reviewers see submitted ones) |
| 2.1 | POST | `/api/portfolio/entries` | any user | Add an interest, skill, publication, project or experience |
| 2.2 | PUT | `/api/portfolio/entries/:entryId` | owner | Edit an entry |
| 2.3 | GET | `/api/portfolio/me` | any user | View my portfolio, grouped by type |
| 2.4 | GET | `/api/portfolio/:userId` | any user | View another user's portfolio |
| 2.5 | DELETE | `/api/portfolio/entries/:entryId` | owner | Delete an entry |

Proposal statuses: Draft, Submitted, Revision Required, Accepted, Rejected.
Portfolio entry types: interest, skill, publication, project, experience.

## Login and roles

Registration and login belong to the authentication module of the group project (Jitu's part), so they are not repeated here. These APIs only **verify** a JWT signed with `JWT_SECRET`. The token payload must contain `id` (the user's MongoDB id) and `role` (`student`, `professor` or `admin`). `npm run seed` signs tokens like that for the demo users.

When the two parts are merged: use the same `JWT_SECRET`, replace `models/User.js` with the shared User model, and change `middleware/auth.js` if the login module puts different keys in the token.

## Project structure

```
server.js              starts Express on port 1509 after MongoDB is connected
config/db.js           MongoDB connection
middleware/            JWT check and role check, JSON error handler
models/                User, Proposal, PortfolioEntry (Mongoose)
routes/proposals.js    APIs 1.1 to 1.6
routes/portfolio.js    APIs 2.1 to 2.5
scripts/seed.js        demo users, sample data, Postman environment
scripts/smoke-test.js  automated end-to-end checks
postman/               collection and environment to import
```

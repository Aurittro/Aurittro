const mongoose = require('mongoose');

// Minimal user model. Registration, login and password handling belong to the authentication
// module of ScholarBridge (another team member's work), so they are NOT implemented here.
// This model only exists so that proposals and portfolios can reference users.
// When the project is merged, replace this file with the shared User model.
const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    role: { type: String, enum: ['student', 'professor', 'admin'], default: 'student' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);

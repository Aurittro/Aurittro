const mongoose = require('mongoose');

const STATUSES = ['Draft', 'Submitted', 'Revision Required', 'Accepted', 'Rejected'];

// One entry per status change, so the student can track what happened and when.
const historySchema = new mongoose.Schema(
  {
    status: { type: String, enum: STATUSES, required: true },
    changedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    note: { type: String, default: '' },
    at: { type: Date, default: Date.now },
  },
  { _id: false }
);

const proposalSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: {
      type: String,
      required: [true, 'title is required'],
      trim: true,
      maxlength: [200, 'title must be at most 200 characters'],
    },
    researchProblem: { type: String, trim: true, default: '' },
    objectives: { type: String, trim: true, default: '' },
    methodology: { type: String, trim: true, default: '' },
    expectedOutcome: { type: String, trim: true, default: '' },
    status: { type: String, enum: STATUSES, default: 'Draft', index: true },
    feedback: { type: String, trim: true, default: '' },
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    reviewedAt: Date,
    submittedAt: Date,
    statusHistory: [historySchema],
  },
  { timestamps: true }
);

// Changes the status and records the change in statusHistory (call save() afterwards).
proposalSchema.methods.moveTo = function (status, userId, note = '') {
  this.status = status;
  this.statusHistory.push({ status, changedBy: userId, note });
};

const Proposal = mongoose.model('Proposal', proposalSchema);

module.exports = { Proposal, STATUSES };

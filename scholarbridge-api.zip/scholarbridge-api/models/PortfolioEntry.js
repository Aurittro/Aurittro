const mongoose = require('mongoose');

const ENTRY_TYPES = ['interest', 'skill', 'publication', 'project', 'experience'];

// One document per portfolio item. A user's portfolio is simply all entries with that user's id.
const portfolioEntrySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: {
      type: String,
      enum: { values: ENTRY_TYPES, message: `type must be one of: ${ENTRY_TYPES.join(', ')}` },
      required: [true, 'type is required'],
    },
    title: {
      type: String,
      required: [true, 'title is required'],
      trim: true,
      maxlength: [200, 'title must be at most 200 characters'],
    },
    description: { type: String, trim: true, default: '' },
    organization: { type: String, trim: true, default: '' }, // institution, journal or company
    link: {
      type: String,
      trim: true,
      default: '',
      validate: {
        validator: (value) => !value || /^https?:\/\/\S+$/i.test(value),
        message: 'link must start with http:// or https://',
      },
    },
    startDate: Date,
    endDate: {
      type: Date,
      validate: {
        validator: function (value) {
          return !value || !this.startDate || value >= this.startDate;
        },
        message: 'endDate cannot be before startDate',
      },
    },
  },
  { timestamps: true }
);

const PortfolioEntry = mongoose.model('PortfolioEntry', portfolioEntrySchema);

module.exports = { PortfolioEntry, ENTRY_TYPES };
